import React from "react";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { getUser } from "../storage/mmkv";
import { RootStackParamList } from "./types";

import TrainerHome from "../screens/trainer/TrainerHome";
import ReceptionTabs from "./ReceptionTabs";
import MemberDetailScreen from "../screens/receptionist/MemberDetailScreen";
import PtSessionDetailScreen from "../screens/receptionist/PtSessionDetailScreen";
import EditMemberScreen from "../screens/receptionist/EditMemberScreen";
import RenewPlanScreen from "../screens/receptionist/RenewPlanScreen";
import AddMemberScreen from "../screens/receptionist/AddMemberScreen";
import BookPtSessionScreen from "../screens/receptionist/BookPtSessionScreen";

const Stack = createNativeStackNavigator<RootStackParamList>();

export default function AppStack() {
  const user = getUser();
  
  // Dynamically set initial screen based on user role
  let initialRoute: keyof RootStackParamList = "ReceptionTabs";
  if (user?.role === "TRAINER") {
    initialRoute = "TrainerHome";
  }

  return (
    <Stack.Navigator initialRouteName={initialRoute} screenOptions={{ headerShown: false }}>
      <Stack.Screen name="TrainerHome" component={TrainerHome} />
      <Stack.Screen name="ReceptionTabs" component={ReceptionTabs} />
      <Stack.Screen name="MemberDetail" component={MemberDetailScreen} />
      <Stack.Screen name="PtSessionDetail" component={PtSessionDetailScreen} />
      <Stack.Screen name="EditMember" component={EditMemberScreen} />
      <Stack.Screen name="RenewPlan" component={RenewPlanScreen} />
      <Stack.Screen name="AddMember" component={AddMemberScreen} />
      <Stack.Screen name="BookPtSession" component={BookPtSessionScreen} />
    </Stack.Navigator>
  );
}